Arthur Wang - awang91
Mason Albert - malber20

Mason did Part 1 of the homework.
Arthur did Part 2 of the homework.
Tested and debugged together.